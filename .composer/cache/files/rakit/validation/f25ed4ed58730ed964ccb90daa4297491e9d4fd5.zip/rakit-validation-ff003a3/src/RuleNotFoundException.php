<?php

namespace Rakit\Validation;

use Exception;

class RuleNotFoundException extends Exception
{
}
