<?php

namespace Rakit\Validation;

class MissingRequiredParameterException extends \Exception
{
}
