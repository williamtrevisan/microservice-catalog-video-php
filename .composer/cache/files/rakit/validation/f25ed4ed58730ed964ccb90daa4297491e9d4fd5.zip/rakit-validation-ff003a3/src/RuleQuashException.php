<?php

namespace Rakit\Validation;

class RuleQuashException extends \Exception
{
}
